const JsxVsHtml =() =>{
    const name="Abishek";

    return (
        <div className="box">
            <h2>JSX vs HTML</h2>
            <p>Hello, {name}</p>
            <p>2+3 ={2+3}</p>
            <input type="text"/>
        </div>
    );
};

export default JsxVsHtml;

